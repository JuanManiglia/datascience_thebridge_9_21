
past_temp = '2017/2018'
curr_temp = '2018/2019'

# Primero apartamos los datos de la temporada pasada
raw_data_past = raw_data[raw_data['Seasons']==past_temp]

df_tot = pd.concat([raw_data_past, df])

df_tot = df_tot.sort_values(by=['DateTime'], ascending=False)

df_tot.to_csv('data/data_to_dash.csv', sep=';')