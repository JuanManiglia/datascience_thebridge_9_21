
def choose_matches(df_dash, max_matches, today):
    
    import datetime
    
    # Filtro los nulos, es decir, los que no se han jugado todavia    
    filter_matches0 = df_dash[df_dash['End_H'].isnull()].sort_values(by=['DateTime'], ascending=True)
    
    # Filtramos a partir de hoy
    if today == True:
        #today = datetime.datetime.now()
        today = datetime.datetime(year=2018, month=10, day=11)
        filter_matches0 = filter_matches0[filter_matches0['DateTime'] >= today]
    
    # De todos estos quiero mostrar los primeros indicados por el parámetro
    if len(filter_matches0) >= max_matches:
        return filter_matches0.head(max_matches)
    else:
        return filter_matches0.tail(max_matches)
    
    
    
def month(m):
    if m == 'Jan':
        return 1
    elif m == 'Feb':
        return 2
    elif m == 'Mar':
        return 3
    elif m == 'Apr':
        return 4
    elif m == 'May':
        return 5
    elif m == 'Jun':
        return 6
    elif m == 'Jul':
        return 7
    elif m == 'Aug':
        return 8
    elif m == 'Sep':
        return 9
    elif m == 'Oct':
        return 10
    elif m == 'Nov':
        return 11
    elif m == 'Dec':
        return 12
    else:
        return 9999


def keyMatch_home(key, data, h_a):
    A = data[data['key_match'] == key]
    return str(A[h_a].values[0])


def marcados(x,z,t, equipo):
        if x == equipo:
            return z
        else:
            return t
        
def H_A(x,equipo):
    if x == equipo:
        return 1
    else:
        return 0 
    

def axis_points(team, data, h_a_filter, axis, num_points):
    A = data[(data['H_ID'] == team) | (data['A_ID'] == team)]
    A['Home_match'] = A.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if h_a_filter == 'H':
        A = A[A['Home_match'] == 1][0:num_points]
    elif h_a_filter == 'A':
        A = A[A['Home_match'] == 0][0:num_points]
    elif h_a_filter == 'HA':
        A = A[0:num_points]
    
    
    if axis == 'x':
        return A['Date'].values
    else:
        A['points_team'] = A.apply(lambda x: marcados(x['H_ID'], x['End_H'], x['End_A'], team), axis=1)
        return A['points_team'].values
    
def points_x_axis(df, teamH, teamA, filterH, filterA, numValues):
    import numpy as np
    
    df = df[~df['End_H'].isnull()]
    
    A = df[(df['H_ID'] == teamH) | (df['A_ID'] == teamH)]
    B = df[(df['H_ID'] == teamA) | (df['A_ID'] == teamA)]
      
    A_dates = axis_points(teamH, A, filterH, 'x', numValues)
    B_dates = axis_points(teamA, B, filterA, 'x', numValues)
    
    # Maximo
    AB_dates_max = max(np.amax(A_dates), np.amax(B_dates))
    
    # Minimo
    AB_dates_min = max(A_dates[4], B_dates[4])
    
    return [AB_dates_min, AB_dates_max]

def wins_A(team, H_ID, End_H, End_A):
    if team == H_ID:
        if End_H >= End_A:
            return 1
        else:
            return 0
    else:
        if End_A >= End_H:
            return 1
        else:
            return 0

def wins_C(team, H_ID, End_H, End_A, dic):
    if team == H_ID:
        if End_H >= End_A:
            return dic['win']
        else:
            return dic['lose']
    else:
        if End_A >= End_H:
            return dic['win']
        else:
            return dic['lose']


def concat_rival_date(team, H, A, month, day):
    if team == H:
        return A + ' ' + str(month) + '-' + str(day)
    else:
        return H + ' ' + str(month) + '-' + str(day)
    
def yy_mm_day_Date(YY, MM, DD):
    return str(YY) + '-' + str(MM) + '-' + str(DD)
    
def wins_B(team, df):
    df_team = df[['H_ID', 'A_ID', 'End_H', 'End_A']]
    A = df_team[(df_team['H_ID'] == team) | (df_team['A_ID'] == team)]
    
    A['wins'] = A.apply(lambda x: wins_A(team, x['H_ID'], x['End_H'], x['End_A']), axis=1)
    
    return A['wins'][0:9].values

def wins_D(team, df, dic):
    df_team = df[['H_ID', 'A_ID', 'End_H', 'End_A']]
    A = df_team[(df_team['H_ID'] == team) | (df_team['A_ID'] == team)]
    
    A['wins'] = A.apply(lambda x: wins_C(team, x['H_ID'], x['End_H'], x['End_A'], dic), axis=1)
    
    return A['wins'][0:9].values
    

def teams_played(team, df):
    df_team = df[['H_ID', 'A_ID', 'End_H', 'End_A', 'MM', 'DD']]
    A = df_team[(df_team['H_ID'] == team) | (df_team['A_ID'] == team)]
    
    A['wins'] = A.apply(lambda x: wins_A(team, x['H_ID'], x['End_H'], x['End_A']), axis=1)
    A['rival_date'] = A.apply(lambda x: concat_rival_date(team, x['H_ID'], x['A_ID'],x['MM'],x['DD']), axis=1)
    
    return A['rival_date'][0:9].values

def matches_teams(df, teamH, teamA):
    df['key_t1'] = df['H_ID'] + df['A_ID']
    key_t1 = teamH + teamA
    key_t2 = teamA + teamH
    keys = [key_t1, key_t2]
    
    A = df[df['key_t1'].isin(keys)]
    A['Match'] = A['H_ID'] + ' vs ' + A['A_ID']
    A['Date2'] = A.apply(lambda x: yy_mm_day_Date(x['YY'], x['MM'],x['DD']), axis=1)
    A = A[['Match', 'End_H', 'End_A', 'Date2', 'H_ID', 'A_ID']]
    
    A = A.rename(columns = {"End_H": "Home Points", 
                                      "End_A":"Away Points", 
                                      "Date2": "Date"})
    return A[0:10]
    
    
def winer_match(t_H, t_A, end_H, end_A):
    if end_H >= end_A:
        return t_H
    else:
        return t_A
    
def rank_position(C, team, df_teams, key):
    import pandas as pd
    import numpy as np
    
    C['Team_ID'] = C.apply(lambda x: winer_match(x['H_ID'], x['A_ID'], x['End_H'], x['End_A']), axis=1)
    
    D = pd.merge(C, df_teams[['Team_ID', 'Conferencia']], on='Team_ID')
    
    conf = df_teams[df_teams['Team_ID'] == team]['Conferencia'].values[0]
    
    if conf == 'E':
        F = D[D['Conferencia']=='E']
    else:
        F = D[D['Conferencia']=='W']
    
    F = F[['YY', 'Team_ID']].groupby(['Team_ID']).agg(['count'])
    
    
    G = F['YY'].sort_values(by=['count'], ascending=False)
    
    H = np.where(G.index==team)[0][0]+1
    
    return H

def row_color(x, color1, color2, teamH, teamA):
#    if (x['Home Points'] >= x['Away Points']) and x['H_ID']==teamH:
#        return color1
#    else:
#        return color2
    if (x['H_ID']==teamH) and (x['Home Points'] >= x['Away Points']):
        return color1
    elif (x['A_ID']==teamH) and (x['Away Points'] >= x['Home Points']):
        return color1
    else:
        return color2
    
    
def wins_played(df, team):
    df_team = df[['H_ID', 'A_ID', 'End_H', 'End_A']]
    A = df_team[(df_team['H_ID'] == team) | (df_team['A_ID'] == team)]
    
    A['wins'] = A.apply(lambda x: wins_A(team, x['H_ID'], x['End_H'], x['End_A']), axis=1)
    
    return str(int(A['wins'].sum()/A['wins'].count()*100)) + '%'
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    








    