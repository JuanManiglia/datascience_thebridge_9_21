
import os
os.chdir('C:/Users/danie/Desktop/Archivos/NBA/Dashboard/Dash/Dashboard')
import pandas as pd
import numpy as np
import calendar
from datetime import date
from datetime import datetime

currentSeason = '2018/2019'

# Leemos los datos del Excel
#df = pd.read_excel('data/web_excel/nba-2018-GMTStandardTime.xlsx')[['Date', 'Home Team', 'Away Team', 'Result']]
#df = df.rename(columns = {'Date': 'DateTime'})

link ='https://fixturedownload.com/download/nba-2018-GMTStandardTime.xlsx'

def load_data(link, currentSeason, write):
    df = pd.read_excel(link,'Fixture')[['Date', 'Home Team', 'Away Team', 'Result']]
    df = df.rename(columns = {'Date': 'DateTime'})
    
    # Cambiamos el nombre a LA Clippers
    def clip_name(x):
        if x == 'LA Clippers':
            return 'Los Angeles Clippers'
        else:
            return x
    
    df['Home Team'] = df.apply(lambda x: clip_name(x['Home Team']), axis=1)
    df['Away Team'] = df.apply(lambda x: clip_name(x['Away Team']), axis=1)
    
    # Teams data
    df_teams = pd.read_excel('data/teams.xlsx')[['Team', 'Conferencia', 'Team_ID', 'Team_ID2', 'Money']]
    
    # Le pegamos a los partidos los datos de sus respectivos equipos
    df = df.rename(columns = {"Home Team": "Team"}) 
    df = pd.merge(df, df_teams, on='Team')
    
    df = df.rename(columns = {'Team': 'Home Team', 'Conferencia': 'Conferencia_H',
                              'Team_ID': 'H_ID', 'Money': 'Money_H', 'Away Team': 'Team',
                              'Team_ID2':'H_ID2'}) 
    
    df = pd.merge(df, df_teams, on='Team')
    df = df.rename(columns = {'Team': 'Away Team', 'Conferencia': 'Conferencia_A',
                              'Team_ID': 'A_ID', 'Money': 'Money_A', 'Team_ID2':'A_ID2'}) 
    
    # Obtenemos los puntos de cada partido
    def get_points(x):
        if x == '':
            return 0
        else:
            return float(x)
       
    df[['End_H','End_A']] = df['Result'].str.split(' - ',expand=True)
    
    df['End_H'] = df.apply(lambda x: get_points(x['End_H']), axis=1)
    df['End_A'] = df.apply(lambda x: get_points(x['End_A']), axis=1)
    
    # Sacamos la columna Seasons
    df['Seasons'] = currentSeason
    
    # Renombramos las columnas Home/Away Team
    df = df.rename(columns = {'Home Team': 'Home', 'Away Team': 'Away'})
    
    # Saco los datos de Year, month, day, time
    df['YY'] = df.apply(lambda x: int(x['DateTime'].year), axis=1)
    df['MM'] = df.apply(lambda x: calendar.month_name[x['DateTime'].month][0:3], axis=1)
    df['MM_num'] = df.apply(lambda x: int(x['DateTime'].month), axis=1)
    df['DD'] = df.apply(lambda x: int(x['DateTime'].day), axis=1)
    df['Time'] = df.apply(lambda x: str(x['DateTime'].hour) + ':' + str(x['DateTime'].minute), axis=1)
    
    def filter_key(year, month, day, time, home, away):
        return str(home) + ' vs ' + str(away) + '  ' + str(year) + '-' + str(month)+ '-' + str(day) + ' ' + str(time)
    
    df['key_match'] = df.apply(lambda x: filter_key(x['YY'], x['MM_num'], x['DD'], x['Time'], x['H_ID2'], x['A_ID2']), axis=1)   
    
    # Pasamos la hora a formato inglés
    df['Time'] = df.apply(lambda x: datetime.strptime(x['Time'], "%H:%M").strftime("%I:%M"), axis=1)
    
    # Obtenemos Date de DateTime 
    df['Date'] = df.apply(lambda x: x['DateTime'].date(), axis=1)
    
    df['DateTime'] = df.apply(lambda x: datetime.combine(x['Date'], datetime.strptime(x['Time'], '%H:%M').time()), axis=1)
    
    
    df = df[['Seasons', 'DateTime', 'Date', 'Home', 'Away', 'H_ID', 'A_ID', 'H_ID2', 'A_ID2',
           'End_H', 'End_A', 'Money_H', 'Money_A', 'Conferencia_H', 'Conferencia_A',
           'YY', 'MM', 'MM_num', 'DD', 'Time', 'key_match']]
    
    df = df.sort_values(by=['Date'])
    
    
    raw_data = pd.read_csv('data/other_seasons.csv', sep=';', index_col=0)
    
    past_seasons = ['2016/2017', '2017/2018']
    
    # Primero apartamos los datos de la temporada pasada
    raw_data = raw_data[raw_data['Seasons'].isin(past_seasons)]
    
    df_tot = pd.concat([raw_data, df])
    df_tot['DateTime'] = pd.to_datetime(df_tot['DateTime'])
    df_tot['Time'] = df_tot.apply(lambda x: datetime.strptime(x['Time'], "%H:%M").strftime("%I:%M"), axis=1)
    
    df_tot = df_tot.sort_values(by=['DateTime'], ascending=False)
    
    if write:
        df_tot.to_csv('data/data_to_dash.csv', sep=';')
    
    return df_tot
