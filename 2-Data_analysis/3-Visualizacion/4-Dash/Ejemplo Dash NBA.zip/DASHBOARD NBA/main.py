
import os
path = 'C:\\Users\\Daney\\Desktop\\DASHBOARD NBA'
os.chdir(path)

import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.figure_factory as ff
import plotly.graph_objs as go
from dash.dependencies import Input, Output
import glob
import os
import flask
from datetime import datetime
import calendar
from datetime import date
from datetime import datetime

import sys
sys.path.insert(0, path + '/styles')

from kpis_styles import *
from filters_styles import *
from graphs_styles import *
from images_styles import *
from styles import *
from funciones import keyMatch_home, axis_points, wins_B, teams_played, wins_D, matches_teams, rank_position, marcados, H_A, row_color, choose_matches, wins_played, points_x_axis


max_matches = 15
temp = '2018/2019'
num_points = 10
link ='https://fixturedownload.com/download/nba-2018-GMTStandardTime.xlsx'
lang = 'Spanish'

dic = pd.read_excel('data/languages.xlsx', sheet_name='Hoja1', index_col='Index')
dic = dic[lang]
colsTable = [dic['table_match'], dic['table_points_home'], dic['table_points_away'], dic['table_date']]



# Matches data
df_dash = pd.read_csv('data/data_to_dash.csv', sep=';')
df_dash['DateTime'] = df_dash.apply(lambda x: datetime.strptime(x['DateTime'], "%Y-%m-%d %H:%M:%S"), axis=1)  

#df_dash = load_data(link, temp, False)

filter_matches = choose_matches(df_dash.copy(), max_matches, True)

df_dash = df_dash[~df_dash['End_H'].isnull()]

# Teams data
df_teams = pd.read_excel('data/teams.xlsx')


# Teams logos
image_directory = 'images/'
list_of_images = [os.path.basename(x) for x in glob.glob('{}*.png'.format(image_directory))]
static_image_route = '/static/'



# Dashboard
app = dash.Dash(__name__)

app.layout = html.Div(style= {'margin': '0 auto'}, children=[
    html.Div([html.Div(
                    className="app-header",
                    children=[
                        html.Div(dic['header_title'], className="app-header--title", style=header_text)
                    ], style=header_style
    ),
    html.Div(html.Div([
            
        html.Div([
                html.Div([html.H2(children=dic['ch_match'], style = filter_title),
                          dcc.Dropdown(id = 'match-filter', options=[{'label': i, 'value': i} for i in filter_matches['key_match'].unique()], style = filter_style, clearable=False, value=filter_matches['key_match'].unique()[0])
                          ]),
                
                html.Div([html.Div([html.H2(id = 'filter_title_H', style = filter_HA_title), dcc.Dropdown(id = 'points_filter_H',
                                         options=[{'label': dic['home_away'], 'value': 'HA'},
                                                  {'label': dic['home'], 'value': 'H'},
                                                  {'label': dic['away'], 'value': 'A'}],
                                         style = points_graph_filter,
                                         clearable=False,
                                         value='HA')], style = home_filter),

                    html.Div([html.H2(id = 'filter_title_A', style = filter_HA_title), dcc.Dropdown(id = 'points_filter_A',
                                 options=[{'label': dic['home_away'], 'value': 'HA'},
                                          {'label': dic['home'], 'value': 'H'},
                                          {'label': dic['away'], 'value': 'A'}],
                                 style = points_graph_filter,
                                 clearable=False,
                                 value='HA')])],
       style = filters_HA_block)], style = filters_block),
                                                               
                
                
        html.Div([
                          html.Div([html.Div(html.Img(id='image_H', style = logo), style = kpis_block),
                                    html.H1(id='title_H', children='Home Team', style=logo_name_h),
                                    html.Div([
                                              html.Div([html.H1(style = kpi_val, id = 'kpi1'),
                                                        html.H1(id = 'kpi1_n', children=dic['classifi'], style = kpi_name)], style = kpi_1),
            
                                              html.Div([html.H1(style = kpi_val, id = 'kpi2'),
                                                        html.H1(id = 'kpi2_n', children=dic['mean_points'], style = kpi_name)], style = kpi_2),
            
                                              html.Div([html.H1(style = kpi_val, id = 'kpi5'),
                                                        html.H1(id = 'kpi5_n', children=dic['wins'], style = kpi_name)], style = kpi_5)
                    
                                           ], style = kpis_block)
                    
                                 ], style=dist_logos),



                html.Div([html.Div(html.Img(id='image_A', style = logo), style = kpis_block),
                          html.H1(id='title_A', children='Away Team', style=logo_name_a),
                              html.Div([        
                                          html.Div([html.H1(style = kpi_val, id = 'kpi3'),
                                                    html.H1(id = 'kpi3_n', children=dic['classifi'], style = kpi_name)], style = kpi_3),
                                          html.Div([html.H1(style = kpi_val, id = 'kpi4'),
                                                    html.H1(id = 'kpi4_n', children=dic['mean_points'], style = kpi_name)], style = kpi_4),
                                          html.Div([html.H1(style = kpi_val, id = 'kpi6'),
                                                    html.H1(id = 'kpi6_n', children=dic['wins'], style = kpi_name)], style = kpi_6)
                
                                       ], style = kpis_block)
                
                              ]),

                ], style=images_block),

      

        html.Div([dcc.Graph(id='points_graph', style = points_graph), dcc.Graph(id='money_graph', style = money_graph)], style = graphs_block),
                        
        dcc.Graph(
            id='heat_map_H',
            style = heat_map_graph1
            ),
        dcc.Graph(
            id='heat_map_A',
            style = heat_map_graph2
            ),
        dcc.Graph(
            id='table_matches',
            style = table_graph
            ),
    ], style=canvas_style), style=canvas_style2)
  ])

])
        


###################################################
# UPDATE LOGOS
###################################################
@app.callback(
    Output('image_H', 'src'),
    [Input('match-filter', 'value')]
)
def update_output_div(input):
      output1 = static_image_route + keyMatch_home(input, filter_matches, 'H_ID') + '.png'
      return output1

@app.callback(
    Output('image_A', 'src'),
    [Input('match-filter', 'value')]
)
def update_output_div2(input):
      output2 = static_image_route + keyMatch_home(input, filter_matches, 'A_ID') + '.png'
      return output2


###################################################
# UPDATE LOGOS TITLE
###################################################
@app.callback(
    Output('title_H', 'children'),
    [Input('match-filter', 'value')]
)
def update_output_div(input):
      return keyMatch_home(input, filter_matches, 'Home')

@app.callback(
    Output('title_A', 'children'),
    [Input('match-filter', 'value')]
)
def update_output_div2(input):
      return keyMatch_home(input, filter_matches, 'Away')
  
###################################################
# UPDATE FILTERS TITLE
###################################################
@app.callback(
    Output('filter_title_H', 'children'),
    [Input('match-filter', 'value')]
)
def update_output_div(input):
      return keyMatch_home(input, filter_matches, 'H_ID2')

@app.callback(
    Output('filter_title_A', 'children'),
    [Input('match-filter', 'value')]
)
def update_output_div2(input):
      return keyMatch_home(input, filter_matches, 'A_ID2')
  
    

  
    
###################################################
# POINTS CHART
###################################################
@app.callback(
    Output('points_graph', 'figure'),
    [Input('match-filter', 'value'),
     Input('points_filter_H', 'value'),
     Input('points_filter_A', 'value')]
)
def update_points_graph(input1, input2, input3):
    teamH = keyMatch_home(input1, filter_matches, 'H_ID')
    teamA = keyMatch_home(input1, filter_matches, 'A_ID')
    
    # Pintamos los datos de esta temporada
    df_dash_temp = df_dash.copy()[df_dash['Seasons'] == temp]
    
    color_axis = dark_sty['cl2']
    
    data = {'data': [
                    {'x': axis_points(teamH, df_dash_temp, input2, 'x', num_points), 'y': axis_points(teamH, df_dash_temp, input2, 'y', num_points), 'type': 'lines', 'name': teamH, 'line': {'width': 4, 'color': dark_sty['clH']}, 'marker':{'width': 1, 'color':dark_sty['clH']}},
                    {'x': axis_points(teamA, df_dash_temp, input3, 'x', num_points), 'y': axis_points(teamA, df_dash_temp, input3, 'y', num_points), 'type': 'lines', 'name': teamA, 'line': {'width': 4, 'color': dark_sty['clA']}, 'marker':{'width': 1, 'color':dark_sty['clA']}}],
            'layout': {'title': {'text': dic['chart_points_title'],
                                 'font': {'size': 21, 'family': dark_sty['font'], 'color':dark_sty['cl3']},
                                 'x': 0.1},
                       'legend':{'font': {'size': 12, 'color':dark_sty['cl2']}},
                       'margin': {'l': 80, 'b': 30, 't': 80, 'r': 80},
                       'xaxis': {'range': points_x_axis(df_dash_temp, teamH, teamA, input2, input3, num_points),
                                 'tickfont': {'color': color_axis}},
                        'yaxis': {'tickfont': {'color': color_axis}},
                       'paper_bgcolor': dark_sty['cl1'],
                       'plot_bgcolor': dark_sty['cl1']}
            }

    return data


###################################################
# BAR MONEY CHART
###################################################
@app.callback(
    Output('money_graph', 'figure'),
    [Input('match-filter', 'value')]
)
def update_bar_graph(input_value):   
    team_H = keyMatch_home(input_value, filter_matches, 'H_ID')
    team_A = keyMatch_home(input_value, filter_matches, 'A_ID')
    
    money_H = df_teams[df_teams['Team_ID']==team_H]['Money'].values[0]
    money_A = df_teams[df_teams['Team_ID']==team_A]['Money'].values[0]
    
    max_money = df_teams['Money'].max()
    max_team = df_teams[df_teams['Money']==max_money]['Team_ID'].values[0]
    
    color_axis = dark_sty['cl2']
    
    bars =  {'data': [
                    {'x': [team_H], 'y': [money_H], 'type': 'bar', 'name': team_H, 'marker':{'color':dark_sty['clH']}},
                    {'x': [team_A], 'y': [money_A], 'type': 'bar', 'name': team_A, 'marker':{'color':dark_sty['clA']}},
                    {'x': [team_H, team_A], 'y': [max_money, max_money], 'type': 'line', 'name': ('Max value-' + max_team)}],
            'layout': {'title': {'text': dic['chart_value_title'],
                                 'font': {'size': 21, 'family': 'Arial', 'color':dark_sty['cl3']},
                                 'x': 0.1},
                       'legend':{'font': {'size': 12, 'color':dark_sty['cl2']}},
                       'margin': {'l': 80, 'b': 30, 't': 80, 'r': 80},
                       'xaxis': {'tickfont': {'color': color_axis}},
                        'yaxis': {'tickfont': {'color': color_axis}},
                       'paper_bgcolor': dark_sty['cl1'],
                       'plot_bgcolor': dark_sty['cl1']}}
                            
    
    return bars

###################################################
# HEAT MAP H
###################################################
@app.callback(
    Output('heat_map_H', 'figure'),
    [Input('match-filter', 'value'),
     Input('points_filter_H', 'value')]
)
def update_heat_map_h_graph(input1, input2):   
    team = keyMatch_home(input1, filter_matches, 'H_ID')
    
    df = df_dash.copy()[(df_dash['H_ID'] == team) | (df_dash['A_ID'] == team)]
    df['Home_match'] = df.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if input2 == 'H':
        df = df[df['Home_match'] == 1]
    elif input2 == 'A':
        df = df[df['Home_match'] == 0]
        
    figure = ff.create_annotated_heatmap(z = [wins_B(team, df).tolist()]  , x = teams_played(team, df).tolist(), y = [team],
                                      annotation_text = [wins_D(team, df, dic).tolist()],xgap=5,
                                      colorscale= [[0, dark_sty['clH_S']], [1, dark_sty['clH']]])
    figure.layout.update(paper_bgcolor = dark_sty['cl1'], plot_bgcolor=dark_sty['cl1'], margin=go.layout.Margin(
            l= 70,
            r= 45,
            b= 35,
            t= 40,
            pad= 0
        ))
    for i in range(len(figure.layout.annotations)):
        figure.layout.annotations[i].font.size = 14
        
    y_axis_template = dict(tickfont=dict(
            size=17,
            color=dark_sty['cl2']
        ))
    x_axis_template = dict(tickfont=dict(
            size=12,
            color=dark_sty['cl2']
        ))
    
    figure.layout.update(yaxis=y_axis_template)
    figure.layout.update(xaxis=x_axis_template)
    
    return figure
                            
###################################################
# HEAT MAP A
###################################################
@app.callback(
    Output('heat_map_A', 'figure'),
    [Input('match-filter', 'value'),
     Input('points_filter_A', 'value')]
)
def update_heat_map_a_graph(input1, input2):   
    team = keyMatch_home(input1, filter_matches, 'A_ID')
    df = df_dash.copy()[(df_dash['H_ID'] == team) | (df_dash['A_ID'] == team)]
    
    df['Home_match'] = df.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if input2 == 'H':
        df = df[df['Home_match'] == 1]
    elif input2 == 'A':
        df = df[df['Home_match'] == 0]
        
        
    figure = ff.create_annotated_heatmap(z = [wins_B(team, df).tolist()]  , x = teams_played(team, df).tolist(), y = [team],
                                      annotation_text = [wins_D(team, df, dic).tolist()],xgap=5,
                                      colorscale= [[0, dark_sty['clA_S']], [1, dark_sty['clA']]])
    
    figure.layout.update(paper_bgcolor = dark_sty['cl1'], plot_bgcolor=dark_sty['cl1'], margin=go.layout.Margin(
            l= 70,
            r= 45,
            b= 35,
            t= 40,
            pad= 0
        ))
    for i in range(len(figure.layout.annotations)):
        figure.layout.annotations[i].font.size = 14
    
    y_axis_template = dict(tickfont=dict(
            size=17,
            color=dark_sty['cl2']
        ))
    x_axis_template = dict(tickfont=dict(
            size=12,
            color=dark_sty['cl2']
        ))
    
    figure.layout.update(yaxis=y_axis_template)
    figure.layout.update(xaxis=x_axis_template)
    
    return figure
    
    
    
###################################################
# TABLE MATCHES
###################################################
@app.callback(
    Output('table_matches', 'figure'),
    [Input('match-filter', 'value')]
)
def update_table_matches(input):
    teamH = keyMatch_home(input, filter_matches, 'H_ID')
    teamA = keyMatch_home(input, filter_matches, 'A_ID')
    
    df_matches = matches_teams(df_dash.copy(), teamH, teamA)
    df_matches['Color'] = df_matches.apply(
                lambda x: row_color(x, dark_sty['clH'], dark_sty['clA'], teamH, teamA), axis=1)
    
    trace = go.Table(
        header=dict(values=colsTable,
                    line = dict(color=dark_sty['cl1']),
                    fill = dict(color=dark_sty['cl7']),
                    font = dict(color = dark_sty['cl6'], size = 18),
                    height = 30),
                    
        cells=dict(values=[df_matches['Match'].values,
                           df_matches['Home Points'].values,
                           df_matches['Away Points'].values,
                           df_matches['Date'].values],
                   line = dict(color=dark_sty['cl1']),
                   fill = dict(color=[df_matches['Color']]),
                   font = dict(color = dark_sty['cl6'], size = 12),
                   height = 25,
                   align = ['center']))

    layout = go.Layout(
            #width = 1050,
            #height=300,
        margin=go.layout.Margin(
            l= 90,
            r= 20,
            b= 0,
            t= 25,
            pad= 0
        ),
        paper_bgcolor=dark_sty['cl1'],
        plot_bgcolor=dark_sty['cl1'])
    data = [trace]
    fig = dict(data=data, layout=layout)
    

    
    return fig





###################################################
# KPI1
###################################################
@app.callback(
    Output('kpi1', 'children'),
    [Input('match-filter', 'value')]
)
def update_KPI1(input):
    team = keyMatch_home(input, filter_matches, 'H_ID')
    df_dash_temp = df_dash[df_dash['Seasons'] == temp]
    return rank_position(df_dash_temp.copy(), team, df_teams, input)

###################################################
# KPI3
###################################################
@app.callback(
    Output('kpi3', 'children'),
    [Input('match-filter', 'value')]
)
def update_KPI3(input):
    team = keyMatch_home(input, filter_matches, 'A_ID')
    df_dash_temp = df_dash[df_dash['Seasons'] == temp]
    return rank_position(df_dash_temp.copy(), team, df_teams, input)

###################################################
# KPI2
###################################################
@app.callback(
    Output('kpi2', 'children'),
    [Input('match-filter', 'value'),
     Input('points_filter_H', 'value')]
)
def update_KPI2(input1, input2):
    team = keyMatch_home(input1, filter_matches, 'H_ID')
    A = df_dash.copy()[(df_dash['H_ID'] == team) | (df_dash['A_ID'] == team)]
    
    A['Home_match'] = A.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if input2 == 'H':
        A = A[A['Home_match'] == 1]
    elif input2 == 'A':
        A = A[A['Home_match'] == 0]
    elif input2 == 'HA':
        A = A
    
    A['points_team'] = A.apply(lambda x: marcados(x['H_ID'], x['End_H'], x['End_A'], team), axis=1)
    return str(round(A['points_team'].mean(),1))

###################################################
# KPI4
###################################################
@app.callback(
    Output('kpi4', 'children'),
    [Input('match-filter', 'value'),
     Input('points_filter_A', 'value')]
)
def update_KPI4(input, input2):
    team = keyMatch_home(input, filter_matches, 'A_ID')
    A = df_dash.copy()[(df_dash['H_ID'] == team) | (df_dash['A_ID'] == team)]
    
    A['Home_match'] = A.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if input2 == 'H':
        A = A[A['Home_match'] == 1]
    elif input2 == 'A':
        A = A[A['Home_match'] == 0]
    elif input2 == 'HA':
        A = A
        
    A['points_team'] = A.apply(lambda x: marcados(x['H_ID'], x['End_H'], x['End_A'], team), axis=1)
    return str(round(A['points_team'].mean(),1))


###################################################
# KPI5
###################################################
@app.callback(
    Output('kpi5', 'children'),
    [Input('match-filter', 'value'),
     Input('points_filter_H', 'value')]
)
def update_KPI5(input, input2):
    team = keyMatch_home(input, filter_matches, 'H_ID')
    df_dash_temp = df_dash.copy()[df_dash['Seasons'] == temp]
    
    A = df_dash_temp[(df_dash_temp['H_ID'] == team) | (df_dash_temp['A_ID'] == team)]
    
    A['Home_match'] = A.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if input2 == 'H':
        A = A[A['Home_match'] == 1]
    elif input2 == 'A':
        A = A[A['Home_match'] == 0]
    elif input2 == 'HA':
        A = A
    
    return wins_played(A, team)

###################################################
# KPI6
###################################################
@app.callback(
    Output('kpi6', 'children'),
    [Input('match-filter', 'value'),
     Input('points_filter_A', 'value')]
)
def update_KPI6(input, input2):
    team = keyMatch_home(input, filter_matches, 'A_ID')
    df_dash_temp = df_dash.copy()[df_dash['Seasons'] == temp]
    
    A = df_dash_temp[(df_dash_temp['H_ID'] == team) | (df_dash_temp['A_ID'] == team)]
    
    A['Home_match'] = A.apply(lambda x: H_A(x['H_ID'], team), axis=1)
    
    if input2 == 'H':
        A = A[A['Home_match'] == 1]
    elif input2 == 'A':
        A = A[A['Home_match'] == 0]
    elif input2 == 'HA':
        A = A
    
    return wins_played(A, team)





###################################################
# KPI2 NAME
###################################################
@app.callback(
    Output('kpi2_n', 'children'),
    [Input('points_filter_H', 'value')]
)
def update_KPI2_N(input2):
    
    if input2 == 'H':
        return (dic['mean_points'] + '\n' + dic['home'])
    elif input2 == 'A':
        return (dic['mean_points'] + '\n' + dic['away'])
    else:
        return (dic['mean_points'])
    
###################################################
# KPI4 NAME
###################################################
@app.callback(
    Output('kpi4_n', 'children'),
    [Input('points_filter_A', 'value')]
)
def update_KPI4_N(input2):
    
    if input2 == 'H':
        return (dic['mean_points'] + '\n' + dic['home'])
    elif input2 == 'A':
        return (dic['mean_points'] + '\n' + dic['away'])
    else:
        return (dic['mean_points'])

###################################################
# KPI5 NAME
###################################################
@app.callback(
    Output('kpi5_n', 'children'),
    [Input('points_filter_H', 'value')]
)
def update_KPI5_N(input2):
    
    if input2 == 'H':
        return (dic['wins'] + '\n' + dic['home'])
    elif input2 == 'A':
        return (dic['wins'] + '\n' + dic['away'])
    else:
        return (dic['wins'])
    
###################################################
# KPI6 NAME
###################################################
@app.callback(
    Output('kpi6_n', 'children'),
    [Input('points_filter_A', 'value')]
)
def update_KPI6_N(input2):
    
    if input2 == 'H':
        return (dic['wins'] + '\n' + dic['home'])
    elif input2 == 'A':
        return (dic['wins'] + '\n' + dic['away'])
    else:
        return (dic['wins'])















    
    
@app.server.route('{}<image_path>.png'.format(static_image_route))
def serve_image(image_path):
    image_name = '{}.png'.format(image_path)
    if image_name not in list_of_images:
        raise Exception('"{}" is excluded from the allowed static files'.format(image_path))
    return flask.send_from_directory(image_directory, image_name)




if __name__ == '__main__':
    app.run_server(debug=True)