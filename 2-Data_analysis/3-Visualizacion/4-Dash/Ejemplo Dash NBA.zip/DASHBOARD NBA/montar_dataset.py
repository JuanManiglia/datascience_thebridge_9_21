# https://www.indatabet.com/bskb-free-3in1.html
import os
#os.chdir('C:/Users/n139528/Desktop/Archivos/REPORTING/Herramientas Lago/NBA')
os.chdir('C:/Users/danie/Desktop/Archivos/NBA/Dashboard/Dash/Dashboard')


import pandas as pd
import numpy as np
import datetime as dt
from funciones import month

# Leemos los datos
raw_data = pd.read_csv('data/bets_nba.csv', sep=';')
raw_data = raw_data.rename(columns = {'Date': 'DateTime'}) 

# Filtramos por temporada
seasons_malas = ['2016/2017', '2017/2018', '2018/2019']
raw_data = raw_data[raw_data['Seasons'].isin(seasons_malas)]

# Me cargo los equipos que no nos interesan
eq_malos = ['Team Stephen', 'Team USA', 'Team World', 'Team Chuck', 'East', 'West', 'Sophomores']
raw_data = raw_data[~raw_data['Home'].isin(eq_malos)]
raw_data = raw_data[~raw_data['Away'].isin(eq_malos)]

# Drop nas
raw_data = raw_data.dropna()

# Drop duplicates
raw_data = raw_data.drop_duplicates()

# Construimos las fechas
raw_data['MM_num'] = raw_data.apply(lambda x: month(x['MM']),axis=1)
raw_data['DateTime'] = raw_data['YY'].map(str) + '-' + raw_data['MM_num'].map(str) + '-' + raw_data['DD'].map(str) + ' ' + raw_data['Time'].map(str)
raw_data['DateTime'] = raw_data['DateTime'].astype('datetime64[ns]')

# Pasamos algunas columnas a numerico
raw_data['End_A'] = pd.to_numeric(raw_data['End_A'])

# Nombre del partido que irá al filtro
def filter_key(year, month, day, time, home, away):
    return str(home) + ' vs ' + str(away) + '  ' + str(year) + '-' + str(month)+ '-' + str(day) + ' ' + str(time)

# Obtenemos los nombres acortados de los equipos
df_teams = pd.read_excel('data/teams.xlsx')
raw_data = pd.merge(raw_data, df_teams[['H_ID', 'Team_ID2', 'Conferencia', 'Money']], on='H_ID')
raw_data = pd.merge(raw_data, df_teams[['A_ID', 'Team_ID2', 'Conferencia', 'Money']], on='A_ID')

raw_data.rename(columns={'Team_ID2_x':'H_ID2','Team_ID2_y':'A_ID2',
                         'Conferencia_x': 'Conferencia_H', 'Conferencia_y': 'Conferencia_A',
                         'Money_x': 'Money_H', 'Money_y': 'Money_A'}, 
                 inplace=True)

raw_data['key_match'] = raw_data.apply(lambda x: filter_key(x['YY'], x['MM_num'], x['DD'], x['Time'], x['H_ID2'], x['A_ID2']), axis=1)

# Obtenemos Date de DateTime 
raw_data['Date'] = raw_data.apply(lambda x: x['DateTime'].date(), axis=1)
    
raw_data = raw_data.sort_values(by=['Date'], ascending=False)


raw_data = raw_data[['Seasons', 'DateTime', 'Date', 'Home', 'Away', 'H_ID', 'A_ID', 'H_ID2', 'A_ID2',
       'End_H', 'End_A', 'Money_H', 'Money_A', 'Conferencia_H', 'Conferencia_A',
       'YY', 'MM', 'MM_num', 'DD', 'Time', 'key_match']]


raw_data.to_csv('data/other_seasons.csv', sep=';')




