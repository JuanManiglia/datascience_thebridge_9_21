
from parameters import *


header_style = {
        'backgroundColor': back1,
        'height': '75px'
        }

header_text = {
        'fontSize': '45px',
        'color': back5,
        'marginLeft': '40px',
        'fontFamily': dark_sty['font']
    }


canvas_style = {
        'backgroundColor': dark_sty['cl1']
        }

canvas_style2 = {
        'backgroundColor': dark_sty['cl1'],
        'display': 'flex',
        'justifyContent': 'center'
        }






