
from parameters import *

height_filters = '10px'
font_size_filters = '13px'

# Filtro de partidos
filter_style = {
                'backgroundColor': dark_sty['cl5'],
                'width': '300px',
                'height':height_filters,
                'fontSize': font_size_filters,
                'fontFamily': dark_sty['font'],
                'borderColor':dark_sty['cl2']
}

# Filtro de home away
points_graph_filter = {
        'width': '170px',
        'backgroundColor': dark_sty['cl5'],
        'height':height_filters,
        'fontSize': font_size_filters,
        'fontFamily': dark_sty['font'],
        'borderColor':dark_sty['cl2']
}

# Separación entre los filtros de home y away
home_filter = {
              'marginRight': '40px'
}


filters_HA_block = {
        'display': 'flex',
        'justifyContent': 'center',
        'marginLeft': '160px'
}

filters_block = {
        'display': 'flex',
        'justifyContent': 'center',
        'marginRight': '15px'
}



# TITULOS
filter_title = {
              'fontSize': '20px',
              'fontFamily': dark_sty['font'],
              'color':dark_sty['cl3']
}

filter_HA_title = {
              'fontSize': '20px',
              'fontFamily': dark_sty['font'],
              'color':dark_sty['cl3']
}