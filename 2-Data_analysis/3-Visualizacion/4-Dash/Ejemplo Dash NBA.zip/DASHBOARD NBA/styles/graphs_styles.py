


from parameters import *

graphs_block = {
        'display': 'flex',
        'justifyContent': 'center'
        }


points_graph = {
        'width': '550px',
        'height': '400px'
}

money_graph = {
        'width': '370px',
        'height': '400px',
        'marginLeft': '20px'
}
heat_map_graph1 = {
        'marginRight': '20px',
        'marginTop': '70px',
        'marginLeft': '50px',
        'height': '140px',
}

heat_map_graph2 = {
        'marginRight': '20px',
        'marginTop': '18px',
        'marginLeft': '50px',
        'height': '140px',
}


table_graph = {
        'marginBottom': '1800px',
        'marginTop': '30px',
        'marginRight': '0px',
        'marginLeft': 'px',
        'textAlign': 'center',
        'height': '400px',
        'width': '950px'
}