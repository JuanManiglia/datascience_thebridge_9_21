


from parameters import *

widthLogos = '300px'
heightLogos = '120px'

dist_logos = {
              'marginRight': '90px'
              }
logo = {
        'display': 'flex',
        'justifyContent': 'center',
        'maxWidth': widthLogos,
        'height': heightLogos,
        'backgroundColor': dark_sty['cl1']
        }


images_block = {
        'display': 'flex',
        'justifyContent': 'center',
        'marginTop':'100px',
        'marginBottom':'30px'
    }