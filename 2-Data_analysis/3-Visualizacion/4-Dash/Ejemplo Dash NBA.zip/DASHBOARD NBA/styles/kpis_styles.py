
from parameters import *

back_kpi = dark_sty['cl1']
distancia_kpis_first = '0px'
distancia_kpis = '30px'
widthkpi = '110px'
heightkpi = '110px'
borderSize = '0.2px'
borderColor= dark_sty['cl2']
border='solid'

logosTitleSize = '21px'

kpis_block = {
              'display': 'flex',
              'justifyContent': 'center'
              }


# ESTILOS DE LOS TEXTOS
kpi_val = {
            'marginBottom': '5px',
            'textAlign': 'center',
            'fontSize': '25px',
            'color':dark_sty['cl3'],
            'fontFamily': dark_sty['font']
}

kpi_name = {
            'textAlign': 'center',
            'fontSize': '12px',
            'color':dark_sty['cl3'],
            'fontFamily': dark_sty['font']
}

logo_name_a = {
              'marginLeft': distancia_kpis_first,
              'display': 'flex',
              'justifyContent': 'center',
              'color':dark_sty['cl2'],
              'fontFamily': dark_sty['font'],
              'fontSize': logosTitleSize
              }

logo_name_h = {
              'marginRight': distancia_kpis_first,
              'display': 'flex',
              'justifyContent': 'center',
              'color':dark_sty['cl2'],
              'fontFamily': dark_sty['font'],
              'fontSize': logosTitleSize
              }



# MEDIDAS Y DISTANCIAS
kpi_1 = {
        'borderWidth': borderSize,
        'borderColor': borderColor,
        'width': widthkpi,
        'height': heightkpi,
        'marginRight': distancia_kpis,
        'background': back_kpi
}

kpi_2 = {
        'borderWidth': borderSize,
        'borderColor': borderColor,
        'width': widthkpi,
        'height': heightkpi,
        'marginRight': distancia_kpis,
        'background': back_kpi
}

kpi_3 = {
        'borderWidth': borderSize,
        'borderColor': borderColor,
        'width': widthkpi,
        'height': heightkpi,
        'marginLeft': distancia_kpis_first,
        'background': back_kpi
}

kpi_4 = {
        'borderWidth': borderSize,
        'borderColor': borderColor,
        'width': widthkpi,
        'height': heightkpi,
        'marginLeft': distancia_kpis,
        'background': back_kpi
}

kpi_5 = {
        'borderWidth': borderSize,
        'borderColor': borderColor,
        'width': widthkpi,
        'height': heightkpi,
        'marginRight': distancia_kpis_first,
        'background': back_kpi
}

kpi_6 = {
        'borderWidth': borderSize,
        'borderColor': borderColor,
        'width': widthkpi,
        'height': heightkpi,
        'marginLeft': distancia_kpis,
        'background': back_kpi
}




