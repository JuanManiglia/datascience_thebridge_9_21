

# COLORS
back1 = '#1C1C1C'# Header
back2 = '#4D4646'
back3 = '#ECECEE'# Fondo del canvas
back4 = '#544B82'
back5 = '#FDFDFD'# KPIS


# Color del equipo Home
color_H = '#00b33c'
color_A = '#990000'

color_soft_H = '#9fff80'
color_soft_A = '#cc6666'


# ESTILOS DE COLORES

# OSCURO
#dark_sty = {
#        'cl1': '#ECECEE', # Fondo del calvas
#        'cl2': '#4D4646', # Reborde de los filtros, ejes de gráficas
#                          # y fondo de cabecera de tablas
#                          
#        'cl3': '#1C1C1C', # Titulos
#        'cl4': '#ECECEE', # Fondo de los logos. De momento es el canvas
#        
#        'cl5': '#ECECEE', # Fondo de los filtros
#        'cl6': '#ECECEE', # Color de las letras de la tabla
#        'cl7': '#295B69', # Color de las letras de la tabla
#        
#        'clH': '#00b33c', # Color fuerte del equipo de casa
#        'clH_S': '#9fff80', # Color suave del equipo de casa
#        
#        'clA': '#990000', # Color fuerte del equipo de fuera
#        'clA_S': '#cc6666', # Color suave del equipo de fuera
#        
#        'font': 'Nirmala UI' # Estilo de todas las palabras del dashboard
#        }


dark_sty = {
        'cl1': '#023A4A', # Fondo del calvas
        'cl2': '#A1B2B6', # Reborde de los filtros, ejes de gráficas
                          # y fondo de cabecera de tablas
        'cl3': '#F6F7F7', # Titulos
        'cl4': '#023A4A', # Fondo de los logos. De momento es el canvas
        
        'cl5': '#ECECEE', # Fondo de los filtros
        'cl6': '#ECECEE', # Color de las letras de la tabla
        'cl7': '#295B69', # Color de las letras de la tabla
        
        'clH': '#990000', # Color fuerte del equipo de casa
        'clH_S': '#ff6666', # Color suave del equipo de casa
        
        'clA': '#2d862d', # Color fuerte del equipo de fuera
        'clA_S': '#66cc66', # Color suave del equipo de fuera
        
        'font': 'Nirmala UI' # Estilo de todas las palabras del dashboard
        }


sp_dic = {
        'head_title': 'Estadísticas NBA',
        'ch_match': 'Escoge un partido'
        }

en_dic = {
        'head_title': 'NBA Stats',
        'ch_match': 'Choose a match'
        }











