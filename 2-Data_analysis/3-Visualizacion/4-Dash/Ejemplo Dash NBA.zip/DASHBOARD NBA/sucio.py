from time import gmtime, strftime
print(strftime("%z", gmtime()))
import time
time.tzname



a = df_tot[0:15]
b = a['Date'].values[0]
c = a['DateTime'].values[0]


df = pd.read_csv("https://raw.githubusercontent.com/plotly/datasets/master/finance-charts-apple.csv")

data = [go.Scatter(
          x=df.Date,
          y=df['AAPL.Close'])]

